-- Fake SMS history for functional tests.
-- Two logical tables (sms and _smsdelivery) are loaded with ONE LOAD DATA
-- statement into a temporary staging table, then split into the real tables.
-- The rows are in the adjacent fakesmses.tsv.gz. jethro_load_demodata
-- decompresses it into a temporary directory and runs this script from there;
-- the mariadb client needs --local-infile=1 because LOAD DATA LOCAL INFILE
-- resolves paths against the client's current working directory.
--
-- sms IDs are offset past any existing rows, so the fixture can also be
-- loaded on top of data that already has SMS history.
START TRANSACTION;

CREATE TEMPORARY TABLE `_fakesms_stage` (
  `kind` VARCHAR(16) NOT NULL,
  `sms_id` INT NULL,
  `body` MEDIUMTEXT NULL,
  `sender` INT NULL,
  `created` DATETIME NULL,
  `scheduled_send_at` DATETIME NULL,
  `personid` INT NULL,
  `status` VARCHAR(64) NULL,
  `provider` VARCHAR(64) NULL
) ENGINE=InnoDB;

LOAD DATA LOCAL INFILE 'fakesmses.tsv'
  INTO TABLE `_fakesms_stage`
  FIELDS TERMINATED BY '\t' ESCAPED BY '\\'
  LINES TERMINATED BY '\n'
  (`kind`, `sms_id`, `body`, `sender`, `created`, `scheduled_send_at`,
   `personid`, `status`, `provider`);

SET @sms_id_base = (SELECT COALESCE(MAX(`id`), 0) FROM `sms`);

INSERT INTO `sms` (`id`, `body`, `sender`, `created`, `scheduled_send_at`)
  SELECT @sms_id_base + `sms_id`, `body`, `sender`, `created`, `scheduled_send_at`
  FROM `_fakesms_stage`
  WHERE `kind` = 'sms';

INSERT INTO `_smsdelivery` (`sms_id`, `personid`, `status`, `provider`)
  SELECT @sms_id_base + `sms_id`, `personid`, `status`, `provider`
  FROM `_fakesms_stage`
  WHERE `kind` = 'delivery';

DROP TEMPORARY TABLE `_fakesms_stage`;

COMMIT;
